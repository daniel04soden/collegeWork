#!/bin/bash
rm -rf logFiles
rm -rf cfg*
rm -rf usa_*
